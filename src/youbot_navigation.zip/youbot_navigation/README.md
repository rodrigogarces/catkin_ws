youbot_navigation
=================

The ROS navigation stack configured for the KUKA youBot.
