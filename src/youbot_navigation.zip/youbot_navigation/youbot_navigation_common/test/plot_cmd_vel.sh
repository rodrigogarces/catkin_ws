rxplot /move_base/cmd_vel/linear/x,/cmd_vel/linear/x /move_base/cmd_vel/angular/z,/cmd_vel/angular/z

