#pragma once
#include<string>
#include<vector>

using namespace std;
class Node
{
public:
	int posicao[2];
	Node *pai;
	float F;
	float G;
	string tag;

	Node();
	Node(int i, int j, Node pai, float G, float H);
	~Node();
	float getF(int destino[2], float fitness);
	float getG();
	float getF();
	void setF(float priority);

private:
	float CalculaCusto(int destino[2], float fitness);
};

